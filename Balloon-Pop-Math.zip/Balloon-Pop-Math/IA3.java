import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.util.List;
/**
 * Write a description of class Number here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class IA3 extends Objectives
{
    private boolean init;
    private List<Answer> a1;
    private List<IA> a2;
    private List<IA2> a3;
    private int a;
    private int b;
    private int c;
    private int d;
    private String s;
    private Font font = new Font("New Times Roman", Font.PLAIN, 56);
    /**
     * 
     */
    public IA3()
    {
        init = false;
    }

    /**
     * Act - do whatever the Number wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(canSee(FireArrow.class))
        {
            s = "Wrong";  
            setRotation(-90);
            draw();
        }
    }    

    /**
     * 
     */
    public void init()
    {
        if(init == false)
        {
            a1 = getWorld().getObjects(Answer.class);
            a2 = getWorld().getObjects(IA.class);
            a3 = getWorld().getObjects(IA2.class);
            if(a1.size()!=0)
            {
                Answer a10 = a1.get(0);
                c = a10.getC();
            }
            if(a2.size()!=0)
            {
                IA a20 = a2.get(0);
                a = a20.getA();
            }
            if(a3.size()!=0)
            {
                IA2 a30 = a3.get(0);
                b = a30.getB();
            }
            d = Greenfoot.getRandomNumber(10);
            while(d==c || d==a || d==b)
            {
                d=Greenfoot.getRandomNumber(10);
            }
            s = "" + d;
            draw();
            init = true;
        }
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public void draw()
    {
        Graphics2D graphics = (new GreenfootImage(1, 1)).getAwtImage().createGraphics();
        graphics.setFont(font);
        FontMetrics fm = graphics.getFontMetrics();
        int width = fm.charsWidth((s).toCharArray(), 0, (s).length());
        GreenfootImage pic = new GreenfootImage(1 + width, font.getSize() * 2);
        pic.setFont(font);
        pic.drawString(s, 0, font.getSize());
        setImage(pic);
    }
    
    /**
     */
    public int getD()
    {
        return d;
    }
    
}

