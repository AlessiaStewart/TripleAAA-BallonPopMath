import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import javax.swing.JOptionPane;

/**
 * The world where everything goes.
 * 
 * @author Michael Berry
 * @version 29/05/08
 */
public class TargetWorld extends World
{

    private Score score;
    private Arrows arrows;
    private boolean levelOne;
    private boolean levelTwo;
    private boolean levelThree;
    private boolean levelFour;
    private boolean levelFive;
    private boolean youWin; 
    private boolean IAinit;    
    private boolean IA2init;
    private boolean IA3init;
    private Man M;
    private Man player;
    private Objectives[] p = new Objectives[4];
    private int A;

    /**
     * Creates a new TargetWorld. Places the counters, man and target.
     */
    public TargetWorld()
    {    
        super(1000, 500, 1);
        score = new Score();
        addObject(score, 900, 10);
        arrows = new Arrows();
        addObject(arrows, 800, 10);
        A = Greenfoot.getRandomNumber(5); 
        levelOne = true;
        IAinit = false;   
        IA2init = false;   
        IA3init = false;   

        prepare();
    }

    /**
     * 
     */
    public Man getPlayer()
    {
        return player;
    }
    
    /**
     * Return the number of arrows left.
     * @return number of arrows left.
     */
    public int getArrows()
    {
        return arrows.getNum();
    }

    /**
     * Add arrows.
     * @num the number of arrows to add.
     */
    public void addArrows(int num)
    {
        arrows.add(num);
    }

    /**
     * Add something to the player's score.
     * @num the number to add to the score.
     */
    public void addScore(int num)
    {
        score.addScore(num);
    }

    /**
     * Called when there are no more arrows left.
     */
    public void gameOver()
    {
        if(getArrows()<=0){
            JOptionPane.showMessageDialog(null, "Game over!\nScore: " + score.getScore());
            Greenfoot.stop();
        }
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */
    private void prepare()
    {
        Man man = new Man();
        addObject(man, 118, 247);
        man.setLocation(485, 441);

        Answer answer = new Answer();
        addObject(answer, 498, 143);
        answer.setLocation(492, 154);
        Welcome welcome = new Welcome();
        addObject(welcome, 560, 217);
        welcome.setLocation(584, 213);
        welcome.setLocation(581, 213);
        ClickDrag clickdrag = new ClickDrag();
        addObject(clickdrag, 457, 233);
        clickdrag.setLocation(417, 348);
        clickdrag.setLocation(479, 430);
        clickdrag.setLocation(380, 385);
        HitPanda hitpanda = new HitPanda();
        addObject(hitpanda, 820, 258);
        hitpanda.setLocation(836, 261);
        hitpanda.setLocation(800, 267);
        clickdrag.setLocation(496, 408);
    }
    
    /**
     * 
     */
    public void addProblem()
    {
        int cc = Greenfoot.getRandomNumber(3);
        if(cc==0)
        {
            Problem1 a = new Problem1();
            addObject(a,497,277);
            Answer c = new Answer();
            addObject(c,144,105);
            c.init();
            IA ia1 = new IA();
            addObject(ia1,871,102);
            ia1.init();
            IA2 ia2 =  new IA2();
            addObject(ia2,150,388);
            ia2.init();
            IA3 ia3 = new IA3();
            addObject(ia3,877,384);
            ia3.init();
        }
        else if(cc==1)
        {
            Problem1 a = new Problem1();
            addObject(a,497,277);
            Answer c = new Answer();
            addObject(c,871,102);
            c.init();
            IA ia1 = new IA();
            addObject(ia1,144,105);
            ia1.init();
            IA2 ia2 =  new IA2();
            addObject(ia2,150,388);
            ia2.init();
            IA3 ia3 = new IA3();
            addObject(ia3,877,384);
            ia3.init();   
        }
        else if(cc==2)
        {
            Problem1 a = new Problem1();
            addObject(a,497,277);
            Answer c = new Answer();
            addObject(c,877,384);
            c.init();
            IA ia1 = new IA();
            addObject(ia1,871,102);
            ia1.init();
            IA2 ia2 =  new IA2();
            addObject(ia2,150,388);
            ia2.init();
            IA3 ia3 = new IA3();
            addObject(ia3,144,105);
            ia3.init();
        }
        else 
        {
            Problem1 a = new Problem1();
            addObject(a,497,277);
            Answer c = new Answer();
            addObject(c,150,388);
            c.init();
            IA ia1 = new IA();
            addObject(ia1,877,384);
            ia1.init();
            IA2 ia2 =  new IA2();
            addObject(ia2,144,105);
            ia2.init();
            IA3 ia3 = new IA3();
            addObject(ia3,871,102);
            ia3.init();
        }
    }
    /**
     * 
     */
    public void runLevels()
    {       
        if(levelOne==true)
        {
            levelOne(); 
        }
        else if(levelTwo==true)
        {
            levelTwo();  
        }
        else if(levelThree==true)
        {
            levelThree(); 
        }
        else if(levelFour==true)
        {
            levelFour(); 
        }
        else if(levelFive==true)
        {
            levelFive();  
        } 
    }
    
     /**
     * 
     */
    public void levelOne()
    {
        levelOne = false;;
        levelTwo = true;
        removeObjects(getObjects(null));
        addProblem();
        player = new Man();
        addObject(player,485,441);
    }  
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public void levelTwo()
    {
        levelTwo = false;
        levelThree = true;  
        removeObjects(getObjects(null)); 
        addProblem();
        player = new Man();
        addObject(player,485,441);
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public void levelThree()
    {
        levelThree = false;
        levelFour =  true;
        removeObjects(getObjects(null)); 
        addProblem();
        player = new Man();
        addObject(player,485,441);
    }
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public void levelFour()
    {
        levelFour = false;
        levelFive =  true;
        removeObjects(getObjects(null)); 
        addProblem();
        player = new Man();
        addObject(player,485,441);
    }
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public void levelFive()
    {
        levelFive = false;
        removeObjects(getObjects(null)); 
        addProblem();
        player = new Man();
        addObject(player,485,441);
    }
}
