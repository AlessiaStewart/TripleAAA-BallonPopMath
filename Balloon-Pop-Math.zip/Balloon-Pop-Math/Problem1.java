import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;

/**
 * Write a description of class Number here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Problem1 extends Objectives
{
    private int a;
    private String s;
    private Font font = new Font("New Times Roman", Font.PLAIN, 100);
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public Problem1()
    { 
        a = Greenfoot.getRandomNumber(6);    
        s = " " + a;
        draw();
    }

     
    /**
     * Act - do whatever the Number wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        
    }    
        
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public int getA()
    {
        return a;
    }
     
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public void draw()
    {
        Graphics2D graphics = (new GreenfootImage(1, 1)).getAwtImage().createGraphics();
        graphics.setFont(font);
        FontMetrics fm = graphics.getFontMetrics();
        int width = fm.charsWidth((s).toCharArray(), 0, (s).length());
        GreenfootImage pic = new GreenfootImage(1 + width, font.getSize() * 2);
        pic.setFont(font);
        pic.drawString(s, 0, font.getSize());
        setImage(pic);
    }

    
}
