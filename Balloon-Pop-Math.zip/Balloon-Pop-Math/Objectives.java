import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Objectives here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Objectives extends Actor
{
    private boolean a;
    private boolean b;
    private boolean c;
    private boolean d;

    /**
     * Act - do whatever the Objectives wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    } 

    /**
     * Return true if we can see an object of class 'clss' right where we are. 
     * False if there is no such object here.
     */
    public boolean canSee(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0, 0, clss);
        return actor != null;        
    }

}
