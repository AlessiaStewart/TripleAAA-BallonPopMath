import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.util.List;
/**
 * Write a description of class Number here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class IA2 extends Objectives
{
    private boolean init;
    private List<Answer> a1;
    private List<IA> a2;
    private int a;
    private int b;
    private int c;
    private int d;
    private String s;
    private Font font = new Font("New Times Roman", Font.PLAIN, 56);
    /**
     * 
     */
    public IA2()
    {
        init = false;
    }

    /**
     * Act - do whatever the Number wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(canSee(FireArrow.class))
        {
            s = "x = 7";  
            draw();
        }
    }    

    /**
     * 
     */
    public void init()
    {
        if(init == false)
        {
            a1 = getWorld().getObjects(Answer.class);
            a2 = getWorld().getObjects(IA.class);
            if(a1.size()!=0)
            {
                Answer a2 = a1.get(0);
                c = a2.getC();
            }
            if(a2.size()!=0)
            {
                IA a3 = a2.get(0);
                a = a3.getA();
            }
            b= Greenfoot.getRandomNumber(10);
            while(b==c || b==a)
            {
                b=Greenfoot.getRandomNumber(10);
            }
            s = "" + b;
            draw();
            init = true;
        }
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public void draw()
    {
        Graphics2D graphics = (new GreenfootImage(1, 1)).getAwtImage().createGraphics();
        graphics.setFont(font);
        FontMetrics fm = graphics.getFontMetrics();
        int width = fm.charsWidth((s).toCharArray(), 0, (s).length());
        GreenfootImage pic = new GreenfootImage(1 + width, font.getSize() * 2);
        pic.setFont(font);
        pic.drawString(s, 0, font.getSize());
        setImage(pic);
    }
    
    /**
     */
    public int getB()
    {
        return b;
    }
    
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public boolean getInit()
    {
        return init;
    }

}
