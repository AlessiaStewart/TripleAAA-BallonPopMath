import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * An arrow that is fired by the Man.
 * 
 * @author your-name-here
 * @version date-here
 */
public class FireArrow extends Actor
{

    private Vector force;
    private int life = 500;
    private boolean last = false;
    private boolean latch = false;
    private TargetWorld world;
    
    /**
     * Called when the arrow is added to the world.
     */
    public void addedToWorld(World world)
    {
        this.world = (TargetWorld)world;
    }

    /**
     * Create a new firearrow with a certain force.
     */
    public FireArrow(Vector force)
    {
        this.force = force;
    }
    
    /**
     * Control the arrow's movement. Delete the arrow if it goes off screen.
     */
    public void act() 
    {
        move();
        
        if (atEdge())
        {
           remove(); 
        }
        
        life--;
        
        if (life < 1)
        {
            remove();
        }
 
    }
    
    public boolean atEdge()
    {
        if (getX() < 20 || getX() > getWorld().getWidth() - 20)
        return true;
        
        if (getY() < 20 || getY() > getWorld().getHeight() - 20)
        return true;
        
        else return false;
                                               }
    
    /**
     * Moves the arrow
     */
    private void move()
    {
        setLocation(getX()+(int)force.getX(), getY()+(int)force.getY());
        setRotation(force.getDirection());
        force.add(new Vector(90, 0.3));  
    }
    
    /**
     * Called if this is the last arrow before the player runs out.
     */
    public void setLast()
    {
        last = true;
    }
    
    /**
     * Remove this arrow from the world. If it is the last arrow, then call the game over method in world.
     */
    private void remove()
    {
        if(last) {
            TargetWorld world = (TargetWorld)getWorld();
            world.gameOver();
        }
        getWorld().removeObject(this);        
    }
    
    /**
     * Called when the arrow hits the target. A latching variable is used so this method is only executed on the initial hit.
     */
    public void hit()
    {
        if(latch) return;
        latch = true;
        TargetWorld world = (TargetWorld)getWorld();
        world.addScore(100);
    }
}
