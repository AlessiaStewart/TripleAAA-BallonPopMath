import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.util.List;
/**
 * Write a description of class Number here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class IA extends Objectives
{
    private boolean init;
    private List<Answer> a1;
    private int a;
    private int b;
    private int c;
    private int d;
    private String s;
    private Font font = new Font("New Times Roman", Font.PLAIN, 56);
    /**
     * 
     */
    public IA()
    {
        init = false;
    }

    /**
     * Act - do whatever the Number wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        if(canSee(FireArrow.class))
        {
            s = "x = 5";  
            draw();
        }
    }    

    /**
     * 
     */
    public void init()
    {
        if(init == false)
        {
            a1 = getWorld().getObjects(Answer.class);
            if(a1.size()!=0)
            {
                Answer a2 = a1.get(0);
                c = a2.getC();
            }
            a = Greenfoot.getRandomNumber(10);
            while(a==c)
            {
                a=Greenfoot.getRandomNumber(10);
            }
            s = "" + a;
            draw();
            init = true;
        }
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public void draw()
    {
        Graphics2D graphics = (new GreenfootImage(1, 1)).getAwtImage().createGraphics();
        graphics.setFont(font);
        FontMetrics fm = graphics.getFontMetrics();
        int width = fm.charsWidth((s).toCharArray(), 0, (s).length());
        GreenfootImage pic = new GreenfootImage(1 + width, font.getSize() * 2);
        pic.setFont(font);
        pic.drawString(s, 0, font.getSize());
        setImage(pic);
    }
    
    /**
     */
    public int getA()
    {
        return a;
    }
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y   a sample parameter for a method
     * @return     the sum of x and y
     */
    public boolean getInit()
    {
        return init;
    }

    
}